# dip-bt17ece033-
Included is the matlab image processing code for bit slicing,color slicing and histogram equalization.
Author:Dhanraj Mahurkar
